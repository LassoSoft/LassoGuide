/*
	Sample source code for LassoCAPI SDK

	This example creates an LCAPI module for Lasso 9 which adds
	the method sample_method
*/
#include "SampleMethodCAPI.h"
#include <stdio.h>
#include <string>

void registerLassoModule()
{
    lasso_registerTagModule( "sample", "method", myTagFunc,
        REG_FLAGS_TAG_DEFAULT, "sample test" );
}

osError myTagFunc( lasso_request_t token, tag_action_t action )
{
    std::basic_string<char> retValue;
    lasso_type_t opt2 = NULL;
    auto_lasso_value_t v;
    INITVAL(&v);

    if( lasso_findTagParam(token, "-option1", &v) == osErrNoErr ) {
        retValue.append("The value of -option1 is ");
        retValue.append(v.data);
    }

    if( lasso_findTagParam2(token, "-option2", &opt2) == osErrNoErr ) {
        double tempValue;
        char tempValueFmtd[128];

        lasso_typeGetDecimal(token, opt2, &tempValue);
        sprintf(tempValueFmtd, "%.15lg", tempValue);

        retValue.append(" The value of -option2 is ");
        retValue.append(tempValueFmtd);
    }

    int count = 0;
    lasso_getTagParamCount(token, &count);

    for( int i = 0; i < count; ++i )
    {
        lasso_getTagParam(token, i, &v);
        if ( v.name == v.data ) {
            retValue.append(" The value of unnamed param is ");
            retValue.append(v.data);
        }
    }

    return lasso_returnTagValueString(token, retValue.c_str(), (int)retValue.length());
}