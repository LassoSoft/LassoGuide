#include "SampleConnector.h"
#include <stdio.h>
#include <string>


void registerLassoModule()
{
    lasso_registerDSModule( "SampleDSConnector", sampleds_func, 0 );
    lasso_log(LOG_LEVEL_ALWAYS, "Loading Sample Data Source Connector");
}

osError sampleds_func( lasso_request_t token, datasource_action_t action, const auto_lasso_value_t * param )
{
    osError err = osErrNoErr;
    auto_lasso_value_t v1, v2, notused;
    bool boolnotused = false;
    const char * ret;
    switch( action )
    {
        case datasourceInit:
            // nothing!
            break;
        case datasourceTerm:
            // nothing!
            break;
        case datasourceCloseConnection: // connections only get closed through here
            // Here's where you would gracefully close the connection
            break;
        case datasourceTickle:
            // 
            break;
        case datasourceNames:
            // Database Names
            lasso_addDataSourceResult(token, "Accounting");
            lasso_addDataSourceResult(token, "Customers");
            break;
        case datasourceTableNames:
            if( strcmp(param->data, "Accounting") == 0 ) {
                lasso_addDataSourceResultUTF8(token, "Payroll");
                lasso_addDataSourceResultUTF8(token, "Payables");
                lasso_addDataSourceResultUTF8(token, "Receivables");
            }
            if( strcmp(param->data, "Customers") == 0 ) {
                lasso_addDataSourceResultUTF8(token, "ContactInfo");
                lasso_addDataSourceResultUTF8(token, "ItemsPurchased");
            }
            break;
        case datasourceSearch:
        case datasourceFindAll:
            lasso_getDataSourceName(token, &v1, &boolnotused, &notused);
            lasso_getTableName(token, &v2);

            if( strcmp(v1.data, "Accounting") == 0 ) {
                int count, i;
                lasso_getInputColumnCount(token, &count);
                for( i=0; i < count; i++) {
                    auto_lasso_value_t columnItem;
                    lasso_getInputColumn(token, i, &columnItem);
                }
                if( strcmp(v2.data, "Payroll") == 0 ) {
                    const char ** values = new const char*[3];
                    unsigned long * sizes = new unsigned long[3];
                    values[0] = "Samuel Goldwyn";
                    values[1] = "1955-03-27";
                    values[2] = "15000.00";
                    sizes[0] = 14;
                    sizes[1] = 10;
                    sizes[2] =  8;
                    
                    lasso_addColumnInfo(token, "Employee" , true, lpTypeString  , kProtectionNone);
                    lasso_addColumnInfo(token, "StartDate", true, lpTypeDateTime, kProtectionNone);
                    lasso_addColumnInfo(token, "Wages"    , true, lpTypeDecimal , kProtectionNone);
                    
                    lasso_addResultRow(token, values, sizes, 3);
                    lasso_setNumRowsFound(token, 1);

                    delete [] sizes;
                    delete [] values;
                }
            }
            if( strcmp(v1.data, "Customers") == 0 ) {
            }
            break;
        
        case datasourceAdd:
            ret = "datasourceAdd was called to append a record<br />";
            lasso_returnTagValueString(token, ret, (int)strlen(ret));

        case datasourceUpdate:
            ret = "datasourceUpdate was called to replace a record<br />";
            lasso_returnTagValueString(token, ret, (int)strlen(ret));

        case datasourceDelete:
            ret = "datasourceDelete was called to remove a record<br />";
            lasso_returnTagValueString(token, ret, (int)strlen(ret));

        case datasourceInfo:
            ret = "datasourceInfo was called<br />";
            lasso_returnTagValueString(token, ret, (int)strlen(ret));

        case datasourcePrepareSQL:
            ret = "datasourcePrepareSQL was called<br />";
            lasso_returnTagValueString(token, ret, (int)strlen(ret));

        case datasourceUnprepareSQL:
            ret = "datasourceUnprepareSQL was called<br />";
            lasso_returnTagValueString(token, ret, (int)strlen(ret));

        case datasourceExecSQL:
            ret = "datasourceExecSQL was called<br />";
            lasso_returnTagValueString(token, ret, (int)strlen(ret));

        default:
            break;
    }

    return err;
}