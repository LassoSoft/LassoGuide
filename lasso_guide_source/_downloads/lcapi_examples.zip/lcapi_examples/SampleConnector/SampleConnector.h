#ifndef _SAMPLECONNECTOR_H_
#define _SAMPLECONNECTOR_H_

#if MACHINE_MACOSX
#include <Lasso9/LassoCAPI.h>
#else
#include "LassoCAPI.h"
#endif

#ifdef WIN32
#define CAPIFILE_EXPORT __declspec(dllexport)
#else
#define CAPIFILE_EXPORT
#endif

extern "C" CAPIFILE_EXPORT void registerLassoModule(void);
osError sampleds_func( lasso_request_t token, datasource_action_t action, const auto_lasso_value_t * param );

#endif