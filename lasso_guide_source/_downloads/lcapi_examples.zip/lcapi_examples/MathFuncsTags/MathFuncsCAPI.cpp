/*
	Sample source code for LassoCAPI SDK

	This example creates an LCAPI module for Lasso Professional 8 which adds
	three new substitution tags to LDML: [example_math_abs], [example_math_sin],
	and [example_math_sqrt].  These tags have been placed in the example_math_ namespace so 
	that they do not interfere with the built-in [math_abs], [math_sin], and [math_sqrt] tags.
*/
#include "MathFuncsCAPI.h"
#include	<math.h>

void registerLassoModule( void )
{
	lasso_registerTagModule( "example_math", "abs", tagMathAbsFunc, REG_FLAGS_TAG_DEFAULT, "Absolute value" );
	lasso_registerTagModule( "example_math", "sin", tagMathSinFunc, REG_FLAGS_TAG_DEFAULT, "Trigonometric Sine function" );
	lasso_registerTagModule( "example_math", "sqrt", tagMathSqrtFunc, REG_FLAGS_TAG_DEFAULT, "Square Root" );
}

//
//	Example usage: example_math_abs(-45.2)
//
osError
tagMathAbsFunc( lasso_request_t token, tag_action_t action )
{
	lasso_type_t theParam = NULL;
	// get the first parameter passed to the tag
	osError err = lasso_getTagParam2(token, 0, &theParam);
	if (err != osErrNoErr) // if no parameter was given, return the error
		return err;
		
	double doubleValue;
	// the the parameter as a C double
	lasso_typeGetDecimal(token, theParam, &doubleValue);

	// now return it as a decimal
	return lasso_returnTagValueDecimal(token, (double)fabs(doubleValue));
}

//
//	Example usage: example_math_sin(-45.2)
//
osError
tagMathSinFunc( lasso_request_t token, tag_action_t action )
{
	lasso_type_t theParam = NULL;
	// get the first parameter passed to the tag
	osError err = lasso_getTagParam2(token, 0, &theParam);
	if (err != osErrNoErr) // if no parameter was given, return the error
		return err;
		
	double doubleValue;
	// the the parameter as a C double
	lasso_typeGetDecimal(token, theParam, &doubleValue);

	// now return it as a decimal
	return lasso_returnTagValueDecimal(token, (double)sin(doubleValue));
}

//
//	Example usage: example_math_sqrt(125)
//
osError
tagMathSqrtFunc( lasso_request_t token, tag_action_t action )
{
	lasso_type_t theParam = NULL;
	// get the first parameter passed to the tag
	osError err = lasso_getTagParam2(token, 0, &theParam);
	if (err != osErrNoErr) // if no parameter was given, return the error
		return err;
		
	double doubleValue;
	// the the parameter as a C double
	lasso_typeGetDecimal(token, theParam, &doubleValue);

	// now return it as a decimal
	return lasso_returnTagValueDecimal(token, (double)sqrt(doubleValue));
}