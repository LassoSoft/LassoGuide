﻿MathFuncsTags

This sample project will build on OS X, Linux or Windows. The project file, MathFuncsTags.sln was created using Microsoft Visual C++ .NET.

This project shows how to build a Lasso tag module..

This project will register three tags:

example_math_abs(<decimal>)
example_math_sin(<decimal>)
example_math_sqrt(<integer>)

The test file MathFuncsCAPI.lasso can be used to test the tag.