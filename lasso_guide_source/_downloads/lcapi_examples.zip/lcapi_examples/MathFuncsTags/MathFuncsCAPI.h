#ifndef _MATHFUNCSCAPI_H_
#define _MATHFUNCSCAPI_H_

#if MACHINE_MACOSX
#include <Lasso9/LassoCAPI.h>
#else
#include "LassoCAPI.h"
#endif

#ifdef WIN32
#define CAPIFILE_EXPORT __declspec(dllexport)
#else
#define CAPIFILE_EXPORT
#endif

extern "C" CAPIFILE_EXPORT void registerLassoModule(void);
osError	tagMathAbsFunc( lasso_request_t token, tag_action_t action );
osError	tagMathSinFunc( lasso_request_t token, tag_action_t action );
osError	tagMathSqrtFunc( lasso_request_t token, tag_action_t action );

#endif