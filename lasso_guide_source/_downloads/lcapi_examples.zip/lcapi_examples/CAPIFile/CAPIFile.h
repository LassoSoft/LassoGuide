#ifndef _CAPIFILE_H_
#define _CAPIFILE_H_

#if MACHINE_MACOSX
#include <Lasso9/LassoCAPI.h>
#else
#include "LassoCAPI.h"
#endif

#ifdef WIN32
#define CAPIFILE_EXPORT __declspec(dllexport)
#else
#define CAPIFILE_EXPORT
#endif

// exported function that Lasso will call
// make sure the name does not get mangled
extern "C" CAPIFILE_EXPORT void registerLassoModule();

// initializer for file type
osError file_init(lasso_request_t token, tag_action_t action);

// call backs
osError file_onCreate(lasso_request_t token, tag_action_t action);

// member tags
osError file_open(lasso_request_t token, tag_action_t action);
osError file_close(lasso_request_t token, tag_action_t action);
osError file_read(lasso_request_t token, tag_action_t action);
osError file_write(lasso_request_t token, tag_action_t action);
osError file_setMode(lasso_request_t token, tag_action_t action);
osError file_setPosition(lasso_request_t token, tag_action_t action);
osError file_getPosition(lasso_request_t token, tag_action_t action);
osError file_size(lasso_request_t token, tag_action_t action);
osError file_get(lasso_request_t token, tag_action_t action);
osError file_name(lasso_request_t token, tag_action_t action);
osError file_path(lasso_request_t token, tag_action_t action);
osError file_getSize(lasso_request_t token, tag_action_t action);
osError file_isOpen(lasso_request_t token, tag_action_t action);
osError file_delete(lasso_request_t token, tag_action_t action);

#endif