#include "CAPIFile.h"
#include <stdio.h>
#include <sys/stat.h>
#if MACHINE_LINUX
#include <errno.h>
#endif
#if MACHINE_MACOSX
#include <errno.h>
#endif
#ifdef WIN32
#include <io.h>
#endif
#define _POSIX_
#include <fcntl.h>
#include <string>

using std::string;

/**
example_file: <path>, <openmode>, <readMode>
->open: <path>, <openmode>, <readMode>
->close
->read: <num bytes>
->write: <string>, <count>, <offset>
->setMode: EXFILE_MODE_LINE, EXFILE_MODE_CHAR (default) this effects how get works
->setPosition: <file position>
->getPosition, returns the current file position
->getSize, returns 1 if more for get to read otherwise 0
->get: <index>, returns char or line depending on mode
->name, returns file name
->path, returns full internal path to file
->size, returns size in bytes

directory
->size, returns number of files
->get: <index> , returns file

openmode is one of: EXFILE_OPENREAD, EXFILE_OPENWRITE, EXFILE_OPENREADWRITE
readmode is one of: EXFILE_MODECHAR, EXFILE_MODELINE
**/

// the type name
static const char * kFileTypeName = "example_file";

// the member method names
static const char * kMemOnCreate    = "onCreate";
static const char * kMemOpen        = "open";
static const char * kMemClose       = "close";
static const char * kMemRead        = "read";
static const char * kMemWrite       = "write";
static const char * kMemSetMode     = "setMode";
static const char * kMemSetPosition = "setPosition";
static const char * kMemGetPosition = "getPosition";
static const char * kMemGetSize     = "getSize";
static const char * kMemSize        = "size";
static const char * kMemGet         = "get";
static const char * kMemName        = "name";
static const char * kMemPath        = "path";
static const char * kMemIsOpen      = "isOpen";
static const char * kMemDelete      = "delete";

// Private data member
static const char * kPrivateMember  = "_private";


// CONSTANTS
// these will get registered with Lasso and can be called like methods
static const char * kFileRead          = "EXFILE_OPENREAD";
static const char * kFileWrite         = "EXFILE_OPENWRITE";
static const char * kFileReadWrite     = "EXFILE_OPENREADWRITE";
static const char * kFileWriteAppend   = "EXFILE_OPENWRITEAPPEND";
static const char * kFileWriteTruncate = "EXFILE_OPENWRITETRUNCATE";

static const char * kFileModeChar = "EXFILE_MODECHAR";
static const char * kFileModeLine = "EXFILE_MODELINE";


enum 
{
	openModeNothing = 0,
	openModeRead,
	openModeWrite,
	openModeReadWrite,
	openModeWriteAppend,
	openModeWriteTruncate
};

// this is the structure we will use internally for tracking our state/mode, etc.
struct file_desc_t
{
	file_desc_t() : fOpenMode(0), fReadMode(0), fFileStr(NULL) {}
	string fPath; // full path name provided when file was opened
	int fOpenMode;
	int fReadMode; // char or line
	FILE * fFileStr; // file desc from OS

};

// converts an internal path (full or relative) into a full platform specific path
inline void internalToFullPath( lasso_request_t token, const char * inPath, osPathname outPath )
{
	strcpy(outPath, inPath);
	//osPathname qualifiedPath;
	//osPathname resolvedPath;
	//lasso_fullyQualifyPath( token, inPath, qualifiedPath );
	//lasso_resolvePath( token, qualifiedPath, resolvedPath );
	//lasso_getPlatformSpecificPath( resolvedPath, outPath );
}

// utility function to provide easy and direct access to the file_desc_t
// the second param will automatically set the error code/msg is the file is not opened
inline file_desc_t * GetFileDesc( lasso_request_t token, bool setErr = true )
{
	lasso_type_t self = NULL;
	lasso_getTagSelf(token, &self);
	if( self )
	{
		file_desc_t * desc = NULL;
		int test = lasso_getPtrMember(token, self, kPrivateMember, reinterpret_cast<void**>(&desc));
		if( desc && desc->fFileStr == NULL && setErr )
		{
			lasso_setResultMessage(token, "The file must be open.");
//			lasso_setResultCode(token, osErrFile);
		}
		return desc;
	}
	return NULL;
}

// common function to return the proper error msg from a fXXX call
// it does not set the result code
inline void SetResultMessage( lasso_request_t token, int err )
{
	switch(err)
	{
	case EACCES:
		lasso_setResultMessage(token, "Search permission is denied on a component of the path prefix, or the file exists and the permissions specified by mode are denied, or the file does not exist and write permission is denied for the parent directory of the file to be created.");
		break;
	case EINVAL:
		lasso_setResultMessage(token, "The value of the type argument is invalid.");
		break;
	case EISDIR:
		lasso_setResultMessage(token, "The named file is a directory, and type requires write access.");
		break;
	case EMFILE:
		lasso_setResultMessage(token, "Too many file descriptors are open in the calling process.");
		break;
	case ENOENT:
		lasso_setResultMessage(token, "A component of filename does not name an existing file, or filename is an empty string.");
		break;
	case ENOMEM:
		lasso_setResultMessage(token, "Insufficient storage space is available.");
		break;
	case ENOTDIR:
		lasso_setResultMessage(token, "A component of the path prefix is not a directory.");
		break;
#ifdef ETXTBSY
	case ETXTBSY:
		lasso_setResultMessage(token, "The file is an executable that is in use, and type requires write access.");
		break;
#endif
	case EBADF:
		lasso_setResultMessage(token, "The file descriptor underlying stream is not valid.");
		break;
	case ESPIPE:
		lasso_setResultMessage(token, "The file descriptor underlying stream is associated with a pipe or FIFO.");
		break;
	case EAGAIN:
		lasso_setResultMessage(token, "The O_NONBLOCK flag is set for the file descriptor underlying stream, and the process would be delayed in the write operation.");
		break;
	case EINTR:
		lasso_setResultMessage(token, "A signal interrupted the call.");
		break;
	case EIO:
		lasso_setResultMessage(token, "An output error occurred.");
		break;
	case ENOSPC:
		lasso_setResultMessage(token, "An attempt is made to write to a full disk.");
		break;
	case ENXIO:
		lasso_setResultMessage(token, "A device error occurred.");
		break; 
	default:
		{
			char msg[1024];
			sprintf(msg, "An unexpected error occurred with the file: %d.", err);
			lasso_setResultMessage(token, msg);
		}
		break;

	}	
}

// common open file helper
inline FILE * DoOpen( lasso_request_t token, const char * path, int om )
{
	const char * openMode = "rb";
//	secure_operation_t op = kReadFiles;
	switch(om)
	{
	case openModeWrite:
		openMode = "wb";
//		op = kWriteFiles;
		break;
	case openModeReadWrite:
		openMode = "r+b";
//		op = kWriteFiles;
		break;
	case openModeWriteAppend:
		openMode = "a+b";
//		op = kWriteFiles;
		break;
	case openModeWriteTruncate:
		openMode = "w+b";
//		op = kWriteFiles;
		break;
	default:
		break;
	}

	// convert the given internal path into a platform specific path
	osPathname xformPath;
	internalToFullPath(token, path, xformPath);

	FILE * f = fopen(xformPath, openMode);
	if( f == NULL )
	{
//		lasso_setResultCode(token, osErrFile);
		SetResultMessage(token, errno);
	}
	return f;
}

void cleanUp(void * ptr)
{
	file_desc_t * desc = reinterpret_cast<file_desc_t *	>(ptr);
	if( desc )
	{
		if( desc->fFileStr != NULL ) // close it
			fclose(desc->fFileStr);

		// delete the struct
		delete desc;
	}
}

void registerLassoModule()
{
	// define the constants for the type
	lasso_type_t t;
	lasso_typeAllocInteger(NULL, &t, openModeRead);
	lasso_registerConstant(kFileRead, t);
	t = NULL;

	lasso_typeAllocInteger(NULL, &t, openModeWrite);
	lasso_registerConstant(kFileWrite, t);
	t = NULL;

	lasso_typeAllocInteger(NULL, &t, openModeReadWrite);
	lasso_registerConstant(kFileReadWrite, t);
	t = NULL;

	lasso_typeAllocInteger(NULL, &t, openModeWriteAppend);
	lasso_registerConstant(kFileWriteAppend, t);
	t = NULL;

	lasso_typeAllocInteger(NULL, &t, openModeWriteTruncate);
	lasso_registerConstant(kFileWriteTruncate, t);
	t = NULL;
	
	lasso_typeAllocInteger(NULL, &t, 0);
	lasso_registerConstant(kFileModeChar, t);
	t = NULL;

	lasso_typeAllocInteger(NULL, &t, 1);
	lasso_registerConstant(kFileModeLine, t);
	t = NULL;

	// register the file type initializer
	lasso_registerTagModule("", kFileTypeName, file_init,
		REG_FLAGS_TYPE_DEFAULT, "Initializer for the file type.");
}

// the type initializer function
osError file_init(lasso_request_t token, tag_action_t action)
{
	// allocate the type that we are initializing
	// this will be the tag's return value
	lasso_type_t file;
	lasso_typeAllocCustom(token, &file, kFileTypeName);

	// add private data member
	lasso_type_t i;
	lasso_typeAllocInteger(token, &i, 0);
	lasso_typeAddDataMember(token, file, kPrivateMember, i);

	// add the member tags
	// we'll define a macro to speed the process up
	// we will make the tag into a reference which will avoid a copy being made
#define ADD_TAG(NAME, FUNC) {	lasso_type_t mem;\
								lasso_typeAllocTag(token, &mem, FUNC);\
								lasso_typeAddMember(token, file, NAME, mem);\
							}

	// add the type's member tags
	ADD_TAG(kMemOpen, file_open);
	ADD_TAG(kMemClose, file_close);
	ADD_TAG(kMemRead, file_read);
	ADD_TAG(kMemWrite, file_write);
	ADD_TAG(kMemSetMode, file_setMode);
	ADD_TAG(kMemSetPosition, file_setPosition);
	ADD_TAG(kMemGetPosition, file_getPosition);
	ADD_TAG(kMemSize, file_size);
	ADD_TAG(kMemGet, file_get);
	ADD_TAG(kMemName, file_name);
	ADD_TAG(kMemPath, file_path);
	ADD_TAG(kMemIsOpen, file_isOpen);
	ADD_TAG(kMemGetSize, file_getSize);
	ADD_TAG(kMemDelete, file_delete);
	// add special callbacks
	ADD_TAG(kMemOnCreate, file_onCreate);

	// set the new type as the tag's return value
	lasso_returnTagValue(token, file);
	return osErrNoErr;
}


osError file_onCreate(lasso_request_t token, tag_action_t)
{
	lasso_type_t self = NULL;
	lasso_getTagSelf(token, &self);
	// allocate our internal pointer and set it
	file_desc_t * desc = new file_desc_t;
	lasso_setPtrMember(token, self, kPrivateMember, desc, &cleanUp);
	if( desc == NULL )
		return osErrFile;

	// see what parameters we are being created with
	int count;
	lasso_getTagParamCount(token, &count);

	if( count > 0 ) // we are given *at the least* a path
	{
		// first param is going to be a string, so use the LCAPI 5 call to get it
		auto_lasso_value_t pathParam;
		pathParam.name = "";
		lasso_getTagParam(token, 0, &pathParam);

		desc->fPath = pathParam.name;
		int64_t om = openModeRead;
		if( count > 1 ) // open mode; this means we will try to open the file. read mode is the default
		{
			lasso_type_t openParam = NULL;
			lasso_getTagParam2(token, 1, &openParam);
			
			if( openParam )
				lasso_typeGetInteger(token, openParam, &om);
		}

		desc->fFileStr = DoOpen(token, desc->fPath.c_str(), (int)om);
		
		if( desc->fFileStr != NULL ) // it was opened ok
			desc->fOpenMode = (int)om;
		else
			return osErrFile;
	}

	if( count > 2 ) // read mode
	{
		lasso_type_t readModeParam = NULL;
		lasso_getTagParam2(token, 2, &readModeParam);

		if( readModeParam )
		{
			int64_t rm;
			lasso_typeGetInteger(token, readModeParam, &rm);
			desc->fReadMode = (int)rm;
		}
	}

	return osErrNoErr;
}

osError file_open(lasso_request_t token, tag_action_t action)
{
	lasso_type_t self = NULL;
	lasso_getTagSelf(token, &self);
	if(!self)
		return osErrInvalidParameter;

	file_desc_t * desc = GetFileDesc(token, false);
	if( desc )
	{
		if( desc->fFileStr != NULL ) // close it
			fclose(desc->fFileStr);
		// delete the struct
		desc->fFileStr = NULL;

		// see what parameters we are being initialized with
		int count;
		lasso_getTagParamCount(token, &count);

		if( count < 2 )
		{
			lasso_setResultMessage(token, "file->open requires at least a file path and open mode.");
			return osErrInvalidParameter;
		}

		if( count > 0 ) // we are given *at the least* a path
		{
			// first param is going to be a string, so use the LCAPI 5 call to get it
			auto_lasso_value_t pathParam;
			pathParam.name = "";
			lasso_getTagParam(token, 0, &pathParam);

			desc->fPath = pathParam.name;
		}
		if( count > 1 ) // open mode; this means we will try to open the file
		{
			lasso_type_t openParam = NULL;
			lasso_getTagParam2(token, 1, &openParam);
			if( openParam )
			{
				int64_t om;
				lasso_typeGetInteger(token, openParam, &om);
				
				desc->fFileStr = DoOpen(token, desc->fPath.c_str(), (int)om);
				if( desc->fFileStr != NULL ) // it was opened ok
					desc->fOpenMode = (int)om;
				else
					return osErrFile;
			}
		}
		if( count > 2 ) // read mode
		{
			lasso_type_t readModeParam = NULL;
			lasso_getTagParam2(token, 2, &readModeParam);
			if( readModeParam )
			{
				int64_t rm;
				lasso_typeGetInteger(token, readModeParam, &rm);
				desc->fReadMode = (int)rm;
			}
		}
	}
	else
		return osErrFile;
	return osErrNoErr;
}

osError file_close(lasso_request_t token, tag_action_t action)
{	
	file_desc_t * desc = GetFileDesc(token, false);
	if( desc )
	{
		if( desc->fFileStr != NULL ) // close it
			fclose(desc->fFileStr);
		desc->fFileStr = NULL;
	}
	else
		return osErrFile;

	return osErrNoErr;
}

// ->read: <num bytes>
osError file_read(lasso_request_t token, tag_action_t action)
{
	lasso_type_t self = NULL;
	lasso_getTagSelf(token, & self);
	if( self )
	{
		lasso_type_t num = NULL;
		if( lasso_getTagParam2(token, 0, &num) == osErrNoErr )
		{
			file_desc_t * desc = NULL;
			lasso_getPtrMember(token, self, kPrivateMember, reinterpret_cast<void**>(&desc));
			if( desc && desc->fFileStr != NULL )
			{
				int64_t n;
				lasso_typeGetInteger(token, num, &n);
				
				char * readInto = new char[(size_t)n];

				size_t wasRead = fread(readInto, sizeof(char), (size_t)n, desc->fFileStr);
				if( wasRead > 0 )
					return lasso_returnTagValueString(token, readInto, (int)wasRead);

				delete [] readInto;
			}
			else
			{
				lasso_setResultMessage(token, "file->read requires that the file be open with read permission.");
				return osErrInvalidParameter;
			}
		}
		else
		{
			lasso_setResultMessage(token, "file->read requires a single parameter: the number of bytes to read.");
			return osErrInvalidParameter;
		}
	}
	return osErrNoErr;
}

osError file_write(lasso_request_t token, tag_action_t action)
{
	lasso_type_t self = NULL;
	lasso_getTagSelf(token, & self);
	if( self )
	{
		auto_lasso_value_t num;
		if( lasso_getTagParam(token, 0, &num) == osErrNoErr )
		{
			file_desc_t * desc = NULL;
			lasso_getPtrMember(token, self, kPrivateMember, reinterpret_cast<void**>(&desc));
			if( desc && desc->fFileStr != NULL )
			{
				int count;
				unsigned int offset = 0, len = num.nameSize;
				lasso_getTagParamCount(token, &count);
				// look for the offset, then the length
				if( count > 1 )
				{
					lasso_type_t param;
					lasso_getTagParam2(token, 1, &param);

					int64_t n;
					lasso_typeGetInteger(token, param, &n);
					offset = (int)n;
				}
				if( count > 2 )
				{
					lasso_type_t param;
					lasso_getTagParam2(token, 2, &param);

					int64_t n;
					lasso_typeGetInteger(token, param, &n);
					len = (int)n;			
				}
				if( offset < num.nameSize )
				{
					num.name += offset;
					num.nameSize -= offset;

					if( len <= num.nameSize )
					{
						num.nameSize = len;
						size_t wasRead = fwrite(num.name, sizeof(char), (size_t)num.nameSize, desc->fFileStr);

						if( wasRead == 0 )
						{
							if( desc->fOpenMode == openModeRead ) // not open in write mode
								lasso_setResultMessage(token, "The file is not open with write permission.");
							else
								SetResultMessage(token, errno);

							return osErrFile;
						}
					}
				}
				// else nothing to write
			}
			else
			{
				lasso_setResultMessage(token, "file->write requires that the file be open with write permission.");
				return osErrInvalidParameter;
			}
		}
		else
		{
			lasso_setResultMessage(token, "file->write requires at least a single parameter: the data to write.");
			return osErrInvalidParameter;
		}
	}
	return osErrNoErr;
}

osError file_setMode(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token);
	if( desc )
	{
		lasso_type_t param = NULL;
		if( lasso_getTagParam2(token, 0, &param) == osErrNoErr )
		{
			int64_t mode;
			lasso_typeGetInteger(token, param, &mode);
			desc->fReadMode = (int)mode;
		}
		else
		{
			lasso_setResultMessage(token, "file->setMode requires one parameter: EXFILE_MODECHAR or EXFILE_MODELINE.");
			return osErrInvalidParameter;
		}
	}
	else
		return osErrFile;

	return osErrNoErr;
}

osError file_setPosition(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token, true);
	
	if( desc && desc->fFileStr )
	{
		lasso_type_t p = NULL;
		if( lasso_getTagParam2(token, 0, &p) == osErrNoErr )
		{
			int64_t iPos;
			lasso_typeGetInteger(token, p, &iPos);
			fseek(desc->fFileStr, (long)iPos, SEEK_SET);
		}
		else
		{
			lasso_setResultMessage(token, "file->setPosition requires a single parameter: the new file position.");
			return osErrInvalidParameter;
		}
	}
	else
		return osErrFile;

	return osErrNoErr;
}

osError file_getPosition(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token);
	if( desc )
	{
		if( desc->fFileStr == NULL )
		{
			lasso_setResultMessage(token, "file->getPosition requires that the file be opened.");
			return osErrFile;
		}
		// flush to insure we get the proper position
		fflush(desc->fFileStr);
		int64_t pos = ftell(desc->fFileStr);
		if( pos == -1 )
		{
			SetResultMessage(token, errno);
			return osErrFile;
		}
		return lasso_returnTagValueInteger(token, pos);
	}
	else
		return osErrFile;

	return osErrNoErr;
}

osError file_getSize(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token);
	if( desc && desc->fFileStr )
	{
		int64_t more = (feof(desc->fFileStr) == 0 ? 1 : 0);
		return lasso_returnTagValueInteger(token, more);
	}
	else
		return osErrFile;

	return osErrNoErr;
}

osError file_get(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token);
	if( desc && desc->fFileStr	)
	{
		if( desc->fReadMode == 1 ) // line mode
		{
			char tmp[1024];
			char * tst = fgets(tmp, 1024, desc->fFileStr);

			if( tst )
				return lasso_returnTagValueString(token, tmp, (int)strlen(tmp));
			else if( errno != 0 )
			{
				SetResultMessage(token, errno);
				return osErrFile;
			}
		}
		else
		{
			int c = fgetc(desc->fFileStr);
			char x = (char)c;

			if( c != EOF )
				return lasso_returnTagValueString(token, &x, 1);
			else if( errno != 0 )
			{
				SetResultMessage(token, errno);
				return osErrFile;
			}
		}
	}
	else
		return osErrFile;

	return osErrNoErr;
}

osError file_name(lasso_request_t token, tag_action_t action)
{
/*
	file_desc_t * desc = GetFileDesc(token);
	if( desc && desc->fPath.length() > 0 )
	{

		char * p;
		p = basename(desc->fPath.c_str());
		if( p )
			return lasso_returnTagValueString(token, p, (int)strlen(p));
	}
*/
	return osErrNoErr;
}

osError file_path(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token);
	if( desc )
		return lasso_returnTagValueString(token, desc->fPath.c_str(), (int)desc->fPath.length());
	else
		return osErrFile;

	return osErrNoErr;
}

osError file_size(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token);

	if( desc && desc->fFileStr )
	{
		fflush(desc->fFileStr);
		struct stat st;
		if( fstat(fileno(desc->fFileStr), &st) == 0 )
			return lasso_returnTagValueInteger(token, (int64_t)st.st_size);
		else
		{
			SetResultMessage(token, errno);
			return osErrFile;
		}
	}
	else
		return osErrFile;

	return osErrNoErr;
}

osError file_isOpen(lasso_request_t token, tag_action_t action)
{
	// if the file desc is not -1, we are open
	lasso_type_t self = NULL;
	lasso_getTagSelf(token, &self);
	if( self )
	{
		file_desc_t * desc = NULL;
		lasso_getPtrMember(token, self, kPrivateMember, reinterpret_cast<void**>(&desc));
		lasso_type_t ret;
		lasso_typeAllocBoolean(token, &ret, desc != NULL && desc->fFileStr != NULL);
		return lasso_returnTagValue(token, ret);
	}
	return osErrNoErr;
}

osError file_delete(lasso_request_t token, tag_action_t action)
{
	file_desc_t * desc = GetFileDesc(token);
	if( desc && desc->fPath.length() > 0 )
	{
		if( desc->fFileStr != NULL )
		{
			fclose(desc->fFileStr);
			desc->fFileStr = NULL;
		}

		osPathname xformPath;
		internalToFullPath(token, desc->fPath.c_str(), xformPath);
		
		if( remove(xformPath) == -1 && errno != 0 )
		{
			SetResultMessage(token, errno);
			return osErrFile;
		}
	}
	else
		return osErrFile;

	return osErrNoErr;
}